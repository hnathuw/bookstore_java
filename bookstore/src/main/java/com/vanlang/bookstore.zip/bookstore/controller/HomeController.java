package com.vanlang.bookstore.controller;

import com.vanlang.bookstore.model.Book;
import com.vanlang.bookstore.service.BookService;
import com.vanlang.bookstore.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final BookService bookService;
    private final CartService cartService;

    // ⭐ TRANG CHỦ
    @GetMapping("/")
    public String home(Model model, Principal principal) {
        model.addAttribute("title", "Trang Chủ");

        // Lấy sách cho trang chủ
        List<Book> featuredBooks = bookService.getFeaturedBooks();
        List<Book> newArrivals   = bookService.getNewArrivals();
        List<Book> bestSellers   = bookService.getBestSellers();

        // Fallback nếu thiếu dữ liệu
        if (featuredBooks.isEmpty()) {
            featuredBooks = bookService.getLatestBooks(8);
        }
        if (newArrivals.isEmpty()) {
            newArrivals = bookService.getLatestBooks(8);
        }
        if (bestSellers.isEmpty()) {
            bestSellers = bookService.getLatestBooks(8);
        }

        model.addAttribute("featuredBooks", featuredBooks);
        model.addAttribute("newArrivals", newArrivals);
        model.addAttribute("bestSellers", bestSellers);

        String username = (principal != null) ? principal.getName() : null;
        model.addAttribute("cartItemCount", cartService.getCartItemCount(username));

        return "index";
    }

    // ⭐ TÌM KIẾM (giữ nguyên vì thường BookController không map /search)
    @GetMapping("/search")
    public String search(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            Model model,
            Principal principal
    ) {
        model.addAttribute("title", "Tìm Kiếm: " + keyword);
        model.addAttribute("keyword", keyword);

        // dùng BookService để phân trang kết quả
        var books = bookService.searchBooks(keyword, page, 12);
        model.addAttribute("books", books);
        model.addAttribute("currentPage", page);

        String username = (principal != null) ? principal.getName() : null;
        model.addAttribute("cartItemCount", cartService.getCartItemCount(username));

        return "search-results";
    }
}
