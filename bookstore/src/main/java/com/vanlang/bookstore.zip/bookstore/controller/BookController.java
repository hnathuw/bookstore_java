package com.vanlang.bookstore.controller;

import com.vanlang.bookstore.model.Book;
import com.vanlang.bookstore.model.Category;
import com.vanlang.bookstore.repository.CategoryRepository;
import com.vanlang.bookstore.service.BookService;
import com.vanlang.bookstore.service.CartService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;
    private final CategoryRepository categoryRepository;
    private final CartService cartService;

    // 📘 Tất cả sách (có phân trang)
    @GetMapping
    public String listBooks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false, defaultValue = "latest") String sort,
            Model model,
            RedirectAttributes ra) {

        Sort sortSpec = switch (sort) {
            case "priceAsc"  -> Sort.by("price").ascending();
            case "priceDesc" -> Sort.by("price").descending();
            case "title"     -> Sort.by("title").ascending();
            default          -> Sort.by("createdAt").descending();
        };

        Pageable pageable = PageRequest.of(page, size, sortSpec);
        Page<Book> bookPage;

        if (categoryId != null) {
            Category category = categoryRepository.findById(categoryId).orElse(null);
            if (category == null) {
                ra.addFlashAttribute("error", "Danh mục không tồn tại hoặc đã bị xóa.");
                return "redirect:/books";
            }
            bookPage = bookService.getBooksByCategory(category, page, size, sortSpec);
            model.addAttribute("selectedCategory", category);
        } else {
            bookPage = bookService.getBooks(page, size, sortSpec);
        }

        model.addAttribute("bookPage", bookPage);
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", bookPage.getTotalPages());
        model.addAttribute("currentSort", sort);
        model.addAttribute("cartItemCount", cartService.getTotalItems());

        return "books";
    }

    // 📖 Chi tiết sách
    @GetMapping("/{id}")
    public String bookDetail(@PathVariable Long id, Model model, RedirectAttributes ra) {
        Book book = bookService.getBookById(id).orElse(null);
        if (book == null) {
            ra.addFlashAttribute("error", "Không tìm thấy sách!");
            return "redirect:/books";
        }

        List<Book> relatedBooks = bookService.getBooksByCategory(book.getCategory(), 0, 4).getContent();

        model.addAttribute("book", book);
        model.addAttribute("relatedBooks", relatedBooks);
        model.addAttribute("cartItemCount", cartService.getTotalItems());

        return "book-detail";
    }

    // 🔍 Tìm kiếm
    @GetMapping("/search")
    public String searchBooks(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size,
            Model model) {

        Page<Book> searchResults = bookService.searchBooks(keyword, page, size);
        model.addAttribute("bookPage", searchResults);
        model.addAttribute("keyword", keyword);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", searchResults.getTotalPages());
        model.addAttribute("cartItemCount", cartService.getTotalItems());
        return "search-results";
    }

    // 🏷️ Danh mục đẹp (slug) - KHÔNG phân trang
    @GetMapping("/c/{slug}")
    public String booksByCategorySlug(
            @PathVariable String slug,
            @RequestParam(defaultValue = "latest") String sort,
            Model model,
            RedirectAttributes ra) {

        Category category = categoryRepository.findBySlug(slug).orElse(null);
        if (category == null) {
            ra.addFlashAttribute("error", "Không tìm thấy danh mục!");
            return "redirect:/books";
        }

        Sort sortSpec = switch (sort) {
            case "priceAsc"  -> Sort.by("price").ascending();
            case "priceDesc" -> Sort.by("price").descending();
            case "title"     -> Sort.by("title").ascending();
            default          -> Sort.by("createdAt").descending();
        };

        // ✅ KHÔNG PHÂN TRANG
        List<Book> books = bookService.getBooksByCategory(category, 0, Integer.MAX_VALUE, sortSpec).getContent();

        model.addAttribute("selectedCategory", category);
        model.addAttribute("bookPage", new org.springframework.data.domain.PageImpl<>(books));
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("currentSort", sort);
        model.addAttribute("cartItemCount", cartService.getTotalItems());

        return "books";
    }

    // ⚙️ Chuyển URL cũ -> URL slug
    @GetMapping(value = "/category/{categoryId}")
    public String redirectOldCategory(@PathVariable Long categoryId) {
        Category cat = categoryRepository.findById(categoryId).orElse(null);
        if (cat == null) return "redirect:/books";
        return "redirect:/books/c/" + cat.getSlug();
    }

    // ==================== ADMIN ====================
    @GetMapping("/admin/manage")
    public String manageBooks(@RequestParam(defaultValue = "0") int page, Model model) {
        Page<Book> bookPage = bookService.getBooks(page, 20);
        model.addAttribute("bookPage", bookPage);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", bookPage.getTotalPages());
        return "admin/manage-books";
    }

    @GetMapping("/admin/add")
    public String showAddBookForm(Model model) {
        model.addAttribute("book", new Book());
        model.addAttribute("categories", categoryRepository.findAll());
        return "admin/add-book";
    }

    @PostMapping("/admin/add")
    public String addBook(@Valid @ModelAttribute("book") Book book,
                          BindingResult result,
                          RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "Vui lòng kiểm tra lại dữ liệu.");
            return "redirect:/books/admin/add";
        }

        try {
            bookService.saveBook(book);
            redirectAttributes.addFlashAttribute("success", "Thêm sách thành công!");
            return "redirect:/books/admin/manage";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Thêm sách thất bại: " + e.getMessage());
            return "redirect:/books/admin/add";
        }
    }

    @GetMapping("/admin/edit/{id}")
    public String showEditBookForm(@PathVariable Long id, Model model, RedirectAttributes ra) {
        Book book = bookService.getBookById(id).orElse(null);
        if (book == null) {
            ra.addFlashAttribute("error", "Không tìm thấy sách!");
            return "redirect:/books/admin/manage";
        }
        model.addAttribute("book", book);
        model.addAttribute("categories", categoryRepository.findAll());
        return "admin/edit-book";
    }

    @PostMapping("/admin/edit/{id}")
    public String updateBook(@PathVariable Long id,
                             @Valid @ModelAttribute("book") Book book,
                             BindingResult result,
                             RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "Vui lòng kiểm tra lại dữ liệu.");
            return "redirect:/books/admin/edit/" + id;
        }

        try {
            book.setId(id);
            bookService.saveBook(book);
            redirectAttributes.addFlashAttribute("success", "Cập nhật sách thành công!");
            return "redirect:/books/admin/manage";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Cập nhật sách thất bại: " + e.getMessage());
            return "redirect:/books/admin/edit/" + id;
        }
    }

    @PostMapping("/admin/delete/{id}")
    public String deleteBook(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            bookService.deleteBook(id);
            redirectAttributes.addFlashAttribute("success", "Xóa sách thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Xóa sách thất bại: " + e.getMessage());
        }
        return "redirect:/books/admin/manage";
    }
}
