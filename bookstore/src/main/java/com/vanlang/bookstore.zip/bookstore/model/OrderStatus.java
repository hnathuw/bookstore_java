package com.vanlang.bookstore.model;

public enum OrderStatus {
    PLACED, PAID, SHIPPING, DELIVERED, COMPLETED, CANCELLED
}
